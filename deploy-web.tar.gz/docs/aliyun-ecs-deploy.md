# 阿里云 ECS 部署说明

这套方案面向阿里云 `ECS Linux`，使用 `Docker + Docker Compose` 部署当前站点。

## 当前部署形态

- Next.js 16 生产构建使用 `output: "standalone"`
- 容器启动时自动执行 `node scripts/init-db.mjs`
- SQLite 持久化目录挂载到宿主机 `./data`
- 默认对外暴露 `80 -> 3000`

## 服务器建议

- 系统：`Alibaba Cloud Linux 3`、`Ubuntu 22.04` 或同类 Linux
- 配置：至少 `2C4G`
- 磁盘：至少 `40GB`
- 安全组开放：
  - `80/tcp`
  - `443/tcp`（如果后续接 Nginx + HTTPS）
  - `22/tcp`（仅运维来源 IP）

## 首次部署

### 1. 安装 Docker 与 Compose

Ubuntu / Debian 示例：

```bash
sudo apt update
sudo apt install -y docker.io docker-compose-plugin
sudo systemctl enable --now docker
```

### 2. 上传项目代码

可以直接在服务器拉取仓库：

```bash
git clone <your-repo-url> /srv/signal-nine-web
cd /srv/signal-nine-web
```

### 3. 准备生产环境变量

```bash
cp .env.production.example .env.production
```

然后编辑 `.env.production`：

```bash
NODE_ENV=production
HOSTNAME=0.0.0.0
PORT=3000
DATABASE_URL=file:/app/data/prod.db
APISPORTS_KEY=你的真实密钥
APISPORTS_TIMEZONE=Asia/Shanghai
```

## 启动

```bash
docker compose -f docker-compose.aliyun.yml up -d --build
```

查看状态：

```bash
docker compose -f docker-compose.aliyun.yml ps
docker compose -f docker-compose.aliyun.yml logs -f
```

## 更新

```bash
git pull
docker compose -f docker-compose.aliyun.yml up -d --build
```

## 数据位置

- 容器内：`/app/data/prod.db`
- 宿主机：项目目录下 `./data/prod.db`

建议把 `./data` 做定时备份。

## 常用排查

### 站点无法访问

1. 确认安全组已放行 `80`
2. 确认容器已启动：

```bash
docker compose -f docker-compose.aliyun.yml ps
```

3. 查看日志：

```bash
docker compose -f docker-compose.aliyun.yml logs -f web
```

### 数据库初始化失败

当前项目只支持 SQLite 文件路径：

```bash
DATABASE_URL=file:/app/data/prod.db
```

不要填成 MySQL/Postgres URL。

### 端口冲突

如果服务器 `80` 端口已被占用，可以改 `docker-compose.aliyun.yml`：

```yaml
ports:
  - "3000:3000"
```

然后通过 `http://服务器IP:3000` 访问。

## 下一步建议

- 在 ECS 前面加 Nginx，接域名和 HTTPS
- 把 SQLite 备份到 OSS 或云盘快照
- 后续如果并发提升，再评估迁移到 MySQL/Postgres

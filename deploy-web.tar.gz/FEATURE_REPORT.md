# Signal Nine Sports MVP — 功能汇总报告

> 生成日期：2026-04-02  
> 项目路径：`C:\Users\14471\Documents\GitHub\web`

---

## 技术栈

| 层级 | 技术 |
|------|------|
| 框架 | Next.js 16 + React 19 |
| 样式 | Tailwind CSS 4 |
| 数据库 | SQLite（通过 Prisma 6.16 ORM） |
| 语言 | TypeScript |
| 外部 API | API-Sports（可选，支持降级到 Mock 数据） |

---

## 一、页面与路由

### 1. 首页 `/`
- Hero 区域 + 精选赛事 Feed
- 热门推荐轮播（付费分析文章）
- 会员套餐展示
- AI 模型预测脉冲展示
- 作者团队网格（含胜率、ROI 等指标）
- 动态首页模块卡片

### 2. 实时赛事
- **足球直播** `/live/football`：按联赛、状态、排序筛选的比分板
- **篮球直播** `/live/basketball`：同上，适配篮球数据结构
- 支持赛事状态：进行中 / 即将开始 / 已结束

### 3. 数据库页面 `/database`
四种视图模式：
- **积分榜**：排名、胜负平、积分
- **赛程**：赛事安排与结果
- **球队**：球队卡片（近期状态、主客场战绩）
- **历史交锋**：H2H 历史对阵记录

支持足球 / 篮球切换，联赛动态筛选。

### 4. 付费内容
- **文章列表** `/plans`：分析文章网格，含作者团队展示、购买入口
- **文章详情** `/plans/[slug]`：完整分析内容（需购买或会员解锁）

### 5. AI 预测 `/ai-predictions`
- 模型命中率、平均边际、可解释因子
- 预测卡片：市场类型、选项、置信度、预期边际、解释文本

### 6. 认证 `/login`
- 预设管理员 / 会员账号快速登录
- 自定义登录（显示名、邮箱、角色选择）
- 支持 `next` 参数跳转回原页面

### 7. 会员中心 `/member`
- 用户资料与会员状态
- 会员套餐购买
- 订单历史（会员订单 + 内容订单）
- 已解锁内容列表
- 支付结果通知

### 8. 管理后台 `/admin`（仅 Admin 角色）
五个 Tab：
- **概览**：核心指标卡片
- **赛事**：数据同步触发、实时赛事列表
- **内容**：作者管理、文章管理、内容初始化
- **用户**：用户列表、订单管理、退款、CSV 导出
- **AI 导入**：批量导入 AI 预测数据

### 9. 结账页 `/checkout`
- 支付流程页面

---

## 二、认证与权限

### 会话系统
- Cookie 会话（30 天有效期）
- 会话 Token 存储于 SQLite
- 无密码登录（MVP 阶段）

### 角色体系
| 角色 | 权限 |
|------|------|
| visitor | 浏览公开内容 |
| member | 访问会员中心、解锁付费内容 |
| operator | 内容管理 |
| admin | 全部权限 + 用户管理 |

### 权限控制点
- `isAuthenticated`：已登录
- `activeMembership`：会员未过期
- `canAccessMemberCenter`：已登录用户
- `canAccessAdminConsole`：仅 Admin
- `canManageContent`：仅 Admin

---

## 三、支付与变现

### 会员套餐（3 档）
- 月度 / 季度 / 年度
- 各含价格、时长、权益说明

### 订单类型
- **会员订单**：订阅购买
- **内容订单**：单篇文章购买

### 订单状态流转
`pending → paid / failed / closed / refunded`

### 支付 API
| 端点 | 说明 |
|------|------|
| `POST /api/member/purchase` | 购买会员 |
| `POST /api/content/purchase` | 购买内容 |
| `POST /api/payments/mock/confirm` | Mock 支付成功 |
| `POST /api/payments/mock/fail` | Mock 支付失败 |
| `POST /api/payments/mock/cancel` | Mock 支付取消 |
| `POST /api/admin/orders/refund` | 管理员退款 |
| `GET /api/admin/orders/export` | 订单 CSV 导出 |

---

## 四、体育数据管理

### 数据模型
- League / Team / Match / OddsSnapshot
- StandingSnapshot / ScheduleSnapshot / HeadToHeadSnapshot

### 数据来源
- **Mock 数据**：始终可用，作为降级方案
- **API-Sports**（需配置 `APISPORTS_KEY`）：
  - API-Football（足球）
  - API-Basketball（篮球）

### 支持运动
- 足球（已实现）
- 篮球（已实现）
- 板球（类型已定义，待实现）

### 数据同步
- 管理员手动触发：`GET /api/admin/sync`
- 同步运行记录（状态、摘要、时间戳）

---

## 五、内容管理

### 文章计划（付费分析）
- 标题、摘要、市场分析、预览文本、完整分析
- 关联运动 / 联赛 / 开球时间
- 价格、绩效指标、标签、"热门"标记
- 状态：草稿 / 已发布 / 已归档

### 作者团队
- 名称、专注领域、徽章
- 绩效指标：连胜、胜率、月 ROI、粉丝数
- 状态：活跃 / 非活跃

### AI 预测记录
- 运动类型、市场类型、选项、置信度
- 预期边际、解释文本、可解释因子
- 结果追踪：pending / won / lost

---

## 六、国际化（i18n）

| 语言 | 代码 |
|------|------|
| 英语 | `en` |
| 简体中文 | `zh-CN` |
| 繁体中文 | `zh-TW` |

覆盖范围：UI 文案、页面文案、角色标签、赛事状态、日期/价格格式化、支付结果消息、管理后台文案。

语言检测：Query 参数 → Cookie → 默认值。

---

## 七、完整 API 端点清单

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/auth/login` | 登录 / 注册 |
| POST | `/api/auth/logout` | 退出登录 |
| GET | `/api/session` | 获取当前会话 |
| POST | `/api/member/purchase` | 购买会员 |
| POST | `/api/content/purchase` | 购买内容 |
| POST | `/api/payments/mock/confirm` | Mock 支付成功 |
| POST | `/api/payments/mock/fail` | Mock 支付失败 |
| POST | `/api/payments/mock/cancel` | Mock 支付取消 |
| POST | `/api/admin/content/authors` | 创建/编辑/切换作者状态 |
| POST | `/api/admin/content/plans` | 创建/编辑/发布/归档/热门切换 |
| POST | `/api/admin/content/bootstrap` | 生成示例内容 |
| POST | `/api/admin/ai-import` | 导入 AI 预测 |
| POST | `/api/admin/orders/refund` | 退款 |
| GET | `/api/admin/orders/export` | 导出订单 CSV |
| GET | `/api/admin/sync` | 触发体育数据同步 |
| GET | `/api/locale` | 获取/设置语言偏好 |

---

## 八、数据库 Schema 概览

```
用户体系
├── User（邮箱、显示名、角色、会员信息）
└── Session（Token、过期时间）

订单体系
├── MembershipOrder（套餐、金额、状态、支付追踪）
└── ContentOrder（内容ID、金额、状态、支付追踪）

体育数据
├── League / Team / Match / OddsSnapshot
└── StandingSnapshot / ScheduleSnapshot / HeadToHeadSnapshot

内容体系
├── AuthorTeam / PredictionRecord
├── ArticlePlan / HomepageModule
└── SyncRun（数据同步记录）
```

---

## 九、UI 组件

| 组件 | 说明 |
|------|------|
| `SiteShell` | 主布局容器 |
| `SiteHeader` | 导航头部 |
| `SiteFooter` | 页脚 |
| `LocaleSwitcher` | 语言切换器 |
| `SectionHeading` | 区块标题（eyebrow + title + desc） |
| `ScoreboardTable` | 比分板表格（含筛选） |
| `SummaryCard` | 指标展示卡片 |
| `PaginationControls` | 分页控件 |

**设计风格**：深色主题（slate/orange/lime 配色）、毛玻璃效果、响应式网格、圆角卡片。

---

## 十、功能完成度总览

| 功能模块 | 状态 |
|----------|------|
| 多运动实时比分板 | ✅ 完成 |
| 付费内容（文章计划）| ✅ 完成 |
| 会员订阅体系 | ✅ 完成 |
| AI 预测展示 | ✅ 完成 |
| 管理后台（内容+用户+订单）| ✅ 完成 |
| Mock 支付流程 | ✅ 完成 |
| 多语言支持（EN/ZH-CN/ZH-TW）| ✅ 完成 |
| 基于角色的访问控制 | ✅ 完成 |
| 体育数据库（积分榜/赛程/H2H）| ✅ 完成 |
| 实时 API 集成（API-Sports）| ✅ 可选接入 |
| 订单 CSV 导出 | ✅ 完成 |
| 退款管理 | ✅ 完成 |
| 响应式深色 UI | ✅ 完成 |
| 板球支持 | 🔲 待实现 |
| 真实支付网关 | 🔲 待接入 |

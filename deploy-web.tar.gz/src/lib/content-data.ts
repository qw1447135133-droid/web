import {
  articlePlans as mockArticlePlans,
  authorTeams as mockAuthorTeams,
  getArticleBySlug as getMockArticleBySlug,
  getPredictionByMatchId as getMockPredictionByMatchId,
  homepageModules as mockHomepageModules,
  predictions as mockPredictions,
} from "@/lib/mock-data";
import {
  localizeArticlePlan,
  localizeAuthorTeam,
  localizeHomepageModule,
  localizePrediction,
} from "@/lib/localized-content";
import {
  getStoredArticlePlanBySlug,
  getStoredArticlePlans,
  getStoredAuthorTeams,
  getStoredHomepageModules,
  getStoredPredictionByMatchId,
  getStoredPredictions,
} from "@/lib/repositories/content-repository";
import { defaultLocale, type Locale } from "@/lib/i18n-config";
import type { ArticlePlan, AuthorTeam, HomepageModule, PredictionRecord, Sport } from "@/lib/types";

function mergeDefined<T extends object>(fallback: T, primary: T) {
  const resolvedPrimary = Object.fromEntries(
    Object.entries(primary).filter(([, value]) => value !== undefined),
  ) as Partial<T>;

  return {
    ...fallback,
    ...resolvedPrimary,
  } as T;
}

function mergeById<T extends { id: string }>(primary: T[], fallback: T[]) {
  const merged = new Map<string, T>();

  for (const item of fallback) {
    merged.set(item.id, item);
  }

  for (const item of primary) {
    const existing = merged.get(item.id);
    merged.set(item.id, existing ? mergeDefined(existing, item) : item);
  }

  return Array.from(merged.values());
}

export async function getHomepageModules(locale: Locale = defaultLocale): Promise<HomepageModule[]> {
  const modules = await getStoredHomepageModules();
  const source = mergeById(modules, mockHomepageModules);
  return source.map((item) => localizeHomepageModule(item, locale));
}

export async function getAuthorTeams(locale: Locale = defaultLocale): Promise<AuthorTeam[]> {
  const authors = await getStoredAuthorTeams();
  const source = mergeById(authors, mockAuthorTeams);
  return source.map((item) => localizeAuthorTeam(item, locale));
}

export async function getArticlePlans(sport?: Sport, locale: Locale = defaultLocale): Promise<ArticlePlan[]> {
  const plans = await getStoredArticlePlans(sport);
  const fallback = sport ? mockArticlePlans.filter((item) => item.sport === sport) : mockArticlePlans;
  const source = mergeById(plans, fallback);

  return source.map((item) => localizeArticlePlan(item, locale));
}

export async function getArticleBySlug(slug: string, locale: Locale = defaultLocale): Promise<ArticlePlan | undefined> {
  const plan = await getStoredArticlePlanBySlug(slug);
  const fallback = getMockArticleBySlug(slug);
  const source = plan && fallback ? mergeDefined(fallback, plan) : (plan ?? fallback);
  return source ? localizeArticlePlan(source, locale) : undefined;
}

export async function getPredictions(sport?: Sport, locale: Locale = defaultLocale): Promise<PredictionRecord[]> {
  const predictions = await getStoredPredictions(sport);
  const fallback = sport ? mockPredictions.filter((item) => item.sport === sport) : mockPredictions;
  const source = mergeById(predictions, fallback);

  return source.map((item) => localizePrediction(item, locale));
}

export async function getPredictionByMatchId(matchId: string, locale: Locale = defaultLocale): Promise<PredictionRecord | undefined> {
  const prediction = await getStoredPredictionByMatchId(matchId);
  const fallback = getMockPredictionByMatchId(matchId) ?? undefined;
  const source = prediction && fallback ? mergeDefined(fallback, prediction) : (prediction ?? fallback);
  return source ? localizePrediction(source, locale) : undefined;
}

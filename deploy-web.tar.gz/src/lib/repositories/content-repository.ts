import { cache } from "react";
import { prisma } from "@/lib/prisma";
import type { ArticlePlan, AuthorTeam, HomepageModule, PredictionRecord, Sport } from "@/lib/types";

function mapSport(value: string): Sport {
  if (value === "basketball" || value === "cricket") {
    return value;
  }

  return "football";
}

function splitList(value: string | null | undefined) {
  if (!value) {
    return [];
  }

  return value
    .split("\n")
    .map((item) => item.trim())
    .filter(Boolean);
}

function splitTags(value: string) {
  return value
    .split("|")
    .map((item) => item.trim())
    .filter(Boolean);
}

function mapAuthor(record: {
  id: string;
  name: string;
  focus: string;
  streak: string;
  winRate: string;
  monthlyRoi: string;
  followers: string;
  badge: string;
}): AuthorTeam {
  return {
    id: record.id,
    name: record.name,
    focus: record.focus,
    streak: record.streak,
    winRate: record.winRate,
    monthlyRoi: record.monthlyRoi,
    followers: record.followers,
    badge: record.badge,
  };
}

function mapPrediction(record: {
  id: string;
  sport: string;
  matchId: string | null;
  market: string;
  pick: string;
  confidence: string;
  expectedEdge: string;
  explanation: string;
  factorsText: string;
  result: string;
  match: { sourceKey: string | null } | null;
}): PredictionRecord {
  return {
    id: record.id,
    sport: mapSport(record.sport),
    matchId: record.match?.sourceKey ?? record.matchId ?? "",
    market: record.market,
    pick: record.pick,
    confidence: record.confidence,
    expectedEdge: record.expectedEdge,
    explanation: record.explanation,
    factors: splitList(record.factorsText),
    result: record.result === "won" || record.result === "lost" ? record.result : "pending",
  };
}

function mapArticlePlan(record: {
  id: string;
  slug: string;
  sport: string;
  matchId?: string | null;
  title: string;
  leagueLabel: string;
  kickoff: Date;
  authorId: string;
  teaser: string;
  marketSummary: string;
  previewText: string | null;
  fullAnalysisText: string;
  price: number;
  isHot: boolean;
  performance: string;
  tagsText: string;
}): ArticlePlan {
  const analysis = splitList(record.fullAnalysisText);

  return {
    id: record.id,
    slug: record.slug,
    sport: mapSport(record.sport),
    matchId: record.matchId ?? undefined,
    title: record.title,
    league: record.leagueLabel,
    kickoff: record.kickoff.toISOString(),
    authorId: record.authorId,
    teaser: record.teaser,
    marketSummary: record.marketSummary,
    analysis: analysis.length > 0 ? analysis : splitList(record.previewText),
    price: record.price,
    isHot: record.isHot,
    performance: record.performance,
    tags: splitTags(record.tagsText),
  };
}

function mapHomepageModule(record: {
  id: string;
  eyebrow: string;
  title: string;
  description: string;
  href: string;
  metric: string;
}): HomepageModule {
  return {
    id: record.id,
    eyebrow: record.eyebrow,
    title: record.title,
    description: record.description,
    href: record.href,
    metric: record.metric,
  };
}

export const getStoredAuthorTeams = cache(async (): Promise<AuthorTeam[]> => {
  try {
    const authors = await prisma.authorTeam.findMany({
      where: { status: "active" },
      orderBy: [{ updatedAt: "desc" }, { name: "asc" }],
    });

    return authors.map(mapAuthor);
  } catch {
    return [];
  }
});

export const getStoredArticlePlans = cache(async (sport?: Sport): Promise<ArticlePlan[]> => {
  try {
    const plans = await prisma.articlePlan.findMany({
      where: {
        status: "published",
        ...(sport ? { sport } : {}),
      },
      orderBy: [{ isHot: "desc" }, { kickoff: "asc" }],
    });

    return plans.map(mapArticlePlan);
  } catch {
    return [];
  }
});

export const getStoredArticlePlanBySlug = cache(async (slug: string): Promise<ArticlePlan | undefined> => {
  try {
    const plan = await prisma.articlePlan.findUnique({
      where: { slug },
    });

    return plan && plan.status === "published" ? mapArticlePlan(plan) : undefined;
  } catch {
    return undefined;
  }
});

export const getStoredArticlePlanPriceById = cache(async (id: string): Promise<{ id: string; price: number } | undefined> => {
  try {
    const plan = await prisma.articlePlan.findUnique({
      where: { id },
      select: {
        id: true,
        price: true,
        status: true,
      },
    });

    if (!plan || plan.status !== "published") {
      return undefined;
    }

    return {
      id: plan.id,
      price: plan.price,
    };
  } catch {
    return undefined;
  }
});

export const getStoredHomepageModules = cache(async (): Promise<HomepageModule[]> => {
  try {
    const modules = await prisma.homepageModule.findMany({
      where: { status: "active" },
      orderBy: [{ sortOrder: "asc" }, { updatedAt: "desc" }],
    });

    return modules.map(mapHomepageModule);
  } catch {
    return [];
  }
});

export const getStoredPredictions = cache(async (sport?: Sport): Promise<PredictionRecord[]> => {
  try {
    const predictions = await prisma.predictionRecord.findMany({
      where: sport ? { sport } : undefined,
      include: {
        match: {
          select: { sourceKey: true },
        },
      },
      orderBy: [{ publishedAt: "desc" }, { createdAt: "desc" }],
    });

    return predictions.map(mapPrediction);
  } catch {
    return [];
  }
});

export const getStoredPredictionByMatchId = cache(async (matchId: string): Promise<PredictionRecord | undefined> => {
  try {
    const prediction = await prisma.predictionRecord.findFirst({
      where: {
        OR: [{ matchId }, { match: { sourceKey: matchId } }],
      },
      include: {
        match: {
          select: { sourceKey: true },
        },
      },
      orderBy: [{ publishedAt: "desc" }, { createdAt: "desc" }],
    });

    return prediction ? mapPrediction(prediction) : undefined;
  } catch {
    return undefined;
  }
});

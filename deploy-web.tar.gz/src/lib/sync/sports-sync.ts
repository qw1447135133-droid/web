import { prisma } from "@/lib/prisma";
import {
  getNowscoreDatabaseSnapshot,
  getNowscoreMatchesBySport,
  getNowscoreTrackedLeagues,
} from "@/lib/nowscore-provider";
import type {
  HeadToHeadRow,
  League,
  ScheduleRow,
  Sport,
  StandingRow,
  Team,
} from "@/lib/types";

function mapSport(value: string): Sport {
  if (value === "basketball" || value === "cricket") {
    return value;
  }

  return "football";
}

type SyncCounts = {
  leagues: number;
  teams: number;
  matches: number;
  oddsSnapshots: number;
  standings: number;
  schedules: number;
  headToHeads: number;
};

type SportSyncBreakdown = {
  sport: Sport;
  leagues: number;
  matches: number;
};

export type SportsSyncSummary = {
  runId: string;
  source: "nowscore";
  scope: "tracked-sports";
  mode: "database-sync";
  status: "completed" | "completed_with_errors" | "failed";
  startedAt: string;
  finishedAt: string;
  durationMs: number;
  counts: SyncCounts;
  sports: SportSyncBreakdown[];
  failures: string[];
};

type StoredLeagueRef = {
  id: string;
  slug: string;
  sport: Sport;
};

type StoredTeamRef = {
  id: string;
  sourceKey: string | null;
  name: string;
  displayName: string | null;
  shortName: string;
};

const syncRunStore = prisma as typeof prisma & {
  syncRun: {
    create(args: {
      data: {
        source: string;
        scope: string;
        status: string;
        startedAt: Date;
      };
    }): Promise<{ id: string }>;
    update(args: {
      where: { id: string };
      data: {
        status: string;
        finishedAt: Date;
        summaryJson?: string;
        errorText?: string;
      };
    }): Promise<unknown>;
  };
};

function createEmptyCounts(): SyncCounts {
  return {
    leagues: 0,
    teams: 0,
    matches: 0,
    oddsSnapshots: 0,
    standings: 0,
    schedules: 0,
    headToHeads: 0,
  };
}

function stringifyPayload(value: unknown) {
  try {
    return JSON.stringify(value);
  } catch {
    return null;
  }
}

function slugify(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

function buildTeamSlug(team: Team) {
  const readable = slugify(team.shortName || team.name || "");
  const sourceId = slugify(team.id) || "team";

  return readable ? `${readable}-${sourceId}` : sourceId;
}

function normalizeName(value: string) {
  return value
    .toLowerCase()
    .replace(/\s+/g, "")
    .replace(/[^a-z0-9\u4e00-\u9fff]/g, "");
}

function buildLeagueSourceKey(league: League) {
  return `league:${league.sport}:${league.id}`;
}

function buildTeamSourceKey(sport: Sport, leagueSlug: string, teamId: string) {
  return `team:${sport}:${leagueSlug}:${teamId}`;
}

function buildMatchSourceKey(sport: Sport, matchId: string) {
  return `match:${sport}:${matchId}`;
}

function parseScore(score: string) {
  const match = score.match(/(\d+)\s*-\s*(\d+)/);

  if (!match) {
    return {
      homeScore: null,
      awayScore: null,
    };
  }

  return {
    homeScore: Number(match[1]),
    awayScore: Number(match[2]),
  };
}

function findTeamIdByName(teams: StoredTeamRef[], teamName: string) {
  const normalized = normalizeName(teamName);

  const direct = teams.find((team) => {
    return [team.name, team.displayName ?? "", team.shortName]
      .filter(Boolean)
      .some((value) => normalizeName(value) === normalized);
  });

  if (direct) {
    return direct.id;
  }

  const fuzzy = teams.find((team) => {
    return [team.name, team.displayName ?? ""]
      .filter(Boolean)
      .some((value) => {
        const candidate = normalizeName(value);
        return candidate.includes(normalized) || normalized.includes(candidate);
      });
  });

  return fuzzy?.id ?? null;
}

async function upsertTrackedLeague(league: League, syncedAt: Date, counts: SyncCounts): Promise<StoredLeagueRef> {
  const stored = await prisma.league.upsert({
    where: { slug: league.slug },
    update: {
      source: "nowscore",
      sourceKey: buildLeagueSourceKey(league),
      sourcePayload: stringifyPayload(league),
      sport: league.sport,
      name: league.name,
      displayName: league.name,
      region: league.region,
      season: league.season,
      featured: league.featured,
      lastSyncedAt: syncedAt,
    },
    create: {
      source: "nowscore",
      sourceKey: buildLeagueSourceKey(league),
      sourcePayload: stringifyPayload(league),
      sport: league.sport,
      slug: league.slug,
      name: league.name,
      displayName: league.name,
      region: league.region,
      season: league.season,
      featured: league.featured,
      lastSyncedAt: syncedAt,
    },
    select: {
      id: true,
      slug: true,
      sport: true,
    },
  });

  counts.leagues += 1;

  return {
    id: stored.id,
    slug: stored.slug,
    sport: mapSport(stored.sport),
  };
}

async function syncLeagueSnapshot(
  league: StoredLeagueRef,
  teams: Team[],
  standings: StandingRow[],
  schedule: ScheduleRow[],
  h2h: HeadToHeadRow[],
  syncedAt: Date,
  counts: SyncCounts,
) {
  const teamIdBySource = new Map<string, string>();

  for (const team of teams) {
    const sourceKey = buildTeamSourceKey(league.sport, league.slug, team.id);
    const stored = await prisma.team.upsert({
      where: {
        source_sourceKey: {
          source: "nowscore",
          sourceKey,
        },
      },
      update: {
        sourcePayload: stringifyPayload(team),
        sport: league.sport,
        slug: buildTeamSlug(team),
        name: team.name,
        displayName: team.name,
        shortName: team.shortName,
        ranking: team.ranking,
        form: team.form,
        homeRecord: team.homeRecord,
        awayRecord: team.awayRecord,
        lastSyncedAt: syncedAt,
        leagueId: league.id,
      },
      create: {
        source: "nowscore",
        sourceKey,
        sourcePayload: stringifyPayload(team),
        sport: league.sport,
        slug: buildTeamSlug(team),
        name: team.name,
        displayName: team.name,
        shortName: team.shortName,
        ranking: team.ranking,
        form: team.form,
        homeRecord: team.homeRecord,
        awayRecord: team.awayRecord,
        lastSyncedAt: syncedAt,
        leagueId: league.id,
      },
      select: { id: true },
    });

    teamIdBySource.set(team.id, stored.id);
    counts.teams += 1;
  }

  await prisma.$transaction(async (tx) => {
    await tx.standingSnapshot.deleteMany({ where: { leagueId: league.id } });
    await tx.scheduleSnapshot.deleteMany({ where: { leagueId: league.id } });
    await tx.headToHeadSnapshot.deleteMany({ where: { leagueId: league.id } });

    if (standings.length > 0) {
      await tx.standingSnapshot.createMany({
        data: standings.map((row) => ({
          source: "nowscore",
          sourcePayload: stringifyPayload(row),
          scope: "overall",
          rank: row.rank,
          teamName: row.team,
          played: row.played,
          win: row.win,
          draw: row.draw,
          loss: row.loss,
          points: row.points,
          form: row.form ?? null,
          homeRecord: row.homeRecord ?? null,
          awayRecord: row.awayRecord ?? null,
          capturedAt: syncedAt,
          leagueId: league.id,
          teamId: row.teamId ? teamIdBySource.get(row.teamId) ?? null : null,
        })),
      });
      counts.standings += standings.length;
    }

    if (schedule.length > 0) {
      await tx.scheduleSnapshot.createMany({
        data: schedule.map((row) => ({
          source: "nowscore",
          sourcePayload: stringifyPayload(row),
          labelDate: row.date,
          fixture: row.fixture,
          result: row.result,
          note: row.note,
          capturedAt: syncedAt,
          leagueId: league.id,
          matchId: null,
        })),
      });
      counts.schedules += schedule.length;
    }

    if (h2h.length > 0) {
      await tx.headToHeadSnapshot.createMany({
        data: h2h.map((row, index) => ({
          source: "nowscore",
          sourcePayload: stringifyPayload(row),
          season: row.season,
          fixture: row.fixture,
          tag: row.tag,
          sortOrder: index,
          capturedAt: syncedAt,
          leagueId: league.id,
        })),
      });
      counts.headToHeads += h2h.length;
    }
  });
}

async function loadStoredTeamsByLeague(leagueIds: string[]) {
  const teams = await prisma.team.findMany({
    where: {
      leagueId: {
        in: leagueIds,
      },
    },
    select: {
      id: true,
      sourceKey: true,
      name: true,
      displayName: true,
      shortName: true,
      leagueId: true,
    },
  });

  const map = new Map<string, StoredTeamRef[]>();

  for (const team of teams) {
    const list = map.get(team.leagueId) ?? [];
    list.push(team);
    map.set(team.leagueId, list);
  }

  return map;
}

async function syncSportMatches(
  sport: Sport,
  leaguesBySlug: Map<string, StoredLeagueRef>,
  teamsByLeagueId: Map<string, StoredTeamRef[]>,
  syncedAt: Date,
  counts: SyncCounts,
) {
  const matches = await getNowscoreMatchesBySport(sport);

  for (const match of matches) {
    const league = leaguesBySlug.get(match.leagueSlug);

    if (!league) {
      continue;
    }

    const teams = teamsByLeagueId.get(league.id) ?? [];
    const score = parseScore(match.score);

    const storedMatch = await prisma.match.upsert({
      where: {
        source_sourceKey: {
          source: "nowscore",
          sourceKey: buildMatchSourceKey(sport, match.id),
        },
      },
      update: {
        sourcePayload: stringifyPayload(match),
        sport,
        slug: slugify(`${match.homeTeam}-${match.awayTeam}-${match.kickoff}`),
        status: match.status,
        kickoff: new Date(match.kickoff),
        clock: match.clock ?? null,
        venue: match.venue,
        leagueId: league.id,
        homeTeamId: findTeamIdByName(teams, match.homeTeam),
        awayTeamId: findTeamIdByName(teams, match.awayTeam),
        homeTeamName: match.homeTeam,
        awayTeamName: match.awayTeam,
        homeScore: score.homeScore,
        awayScore: score.awayScore,
        scoreText: match.score,
        statLine: match.statLine,
        insight: match.insight,
        lastSyncedAt: syncedAt,
      },
      create: {
        source: "nowscore",
        sourceKey: buildMatchSourceKey(sport, match.id),
        sourcePayload: stringifyPayload(match),
        sport,
        slug: slugify(`${match.homeTeam}-${match.awayTeam}-${match.kickoff}`),
        status: match.status,
        kickoff: new Date(match.kickoff),
        clock: match.clock ?? null,
        venue: match.venue,
        leagueId: league.id,
        homeTeamId: findTeamIdByName(teams, match.homeTeam),
        awayTeamId: findTeamIdByName(teams, match.awayTeam),
        homeTeamName: match.homeTeam,
        awayTeamName: match.awayTeam,
        homeScore: score.homeScore,
        awayScore: score.awayScore,
        scoreText: match.score,
        statLine: match.statLine,
        insight: match.insight,
        lastSyncedAt: syncedAt,
      },
      select: { id: true },
    });

    counts.matches += 1;

    await prisma.oddsSnapshot.create({
      data: {
        source: "nowscore",
        sourceKey: `${buildMatchSourceKey(sport, match.id)}:${syncedAt.toISOString()}`,
        sourcePayload: stringifyPayload(match.odds),
        market: "main",
        home: match.odds.home,
        draw: match.odds.draw ?? null,
        away: match.odds.away,
        spread: match.odds.spread,
        total: match.odds.total,
        movement: match.odds.movement,
        capturedAt: syncedAt,
        matchId: storedMatch.id,
      },
    });

    counts.oddsSnapshots += 1;
  }

  return matches.length;
}

export async function runTrackedSportsSync(): Promise<SportsSyncSummary> {
  const startedAt = new Date();
  const counts = createEmptyCounts();
  const failures: string[] = [];

  const syncRun = await syncRunStore.syncRun.create({
    data: {
      source: "nowscore",
      scope: "tracked-sports",
      status: "running",
      startedAt,
    },
  });

  try {
    const sports: Sport[] = ["football", "basketball"];
    const sportBreakdown: SportSyncBreakdown[] = [];
    const leaguesBySlug = new Map<string, StoredLeagueRef>();

    for (const sport of sports) {
      const trackedLeagues = await getNowscoreTrackedLeagues(sport);

      for (const league of trackedLeagues) {
        const storedLeague = await upsertTrackedLeague(league, startedAt, counts);
        leaguesBySlug.set(league.slug, storedLeague);

        try {
          const snapshot = await getNowscoreDatabaseSnapshot(sport, league.slug);

          if (!snapshot) {
            failures.push(`${sport}:${league.slug}: snapshot unavailable`);
            continue;
          }

          await syncLeagueSnapshot(
            storedLeague,
            snapshot.teams,
            snapshot.standings,
            snapshot.schedule,
            snapshot.h2h,
            startedAt,
            counts,
          );
        } catch (error) {
          failures.push(`${sport}:${league.slug}: ${error instanceof Error ? error.message : "snapshot sync failed"}`);
        }
      }
    }

    const teamsByLeagueId = await loadStoredTeamsByLeague(Array.from(leaguesBySlug.values()).map((league) => league.id));

    for (const sport of sports) {
      try {
        const matchCount = await syncSportMatches(sport, leaguesBySlug, teamsByLeagueId, startedAt, counts);

        sportBreakdown.push({
          sport,
          leagues: Array.from(leaguesBySlug.values()).filter((league) => league.sport === sport).length,
          matches: matchCount,
        });
      } catch (error) {
        failures.push(`${sport}: match sync failed - ${error instanceof Error ? error.message : "unknown error"}`);
        sportBreakdown.push({
          sport,
          leagues: Array.from(leaguesBySlug.values()).filter((league) => league.sport === sport).length,
          matches: 0,
        });
      }
    }

    const finishedAt = new Date();
    const summary: SportsSyncSummary = {
      runId: syncRun.id,
      source: "nowscore",
      scope: "tracked-sports",
      mode: "database-sync",
      status: failures.length > 0 ? "completed_with_errors" : "completed",
      startedAt: startedAt.toISOString(),
      finishedAt: finishedAt.toISOString(),
      durationMs: finishedAt.getTime() - startedAt.getTime(),
      counts,
      sports: sportBreakdown,
      failures,
    };

    await syncRunStore.syncRun.update({
      where: { id: syncRun.id },
      data: {
        status: summary.status,
        finishedAt,
        summaryJson: JSON.stringify(summary),
      },
    });

    return summary;
  } catch (error) {
    const finishedAt = new Date();
    const message = error instanceof Error ? error.message : "sync failed";

    await syncRunStore.syncRun.update({
      where: { id: syncRun.id },
      data: {
        status: "failed",
        finishedAt,
        errorText: message,
      },
    });

    throw error;
  }
}

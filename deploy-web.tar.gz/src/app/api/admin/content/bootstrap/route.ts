import { NextRequest, NextResponse } from "next/server";
import { bootstrapMockContent } from "@/lib/admin-content";
import { getSessionContext } from "@/lib/session";

function redirectToAdmin(request: NextRequest, suffix = "") {
  return NextResponse.redirect(new URL(`/admin?tab=content${suffix}`, request.url));
}

export async function POST(request: NextRequest) {
  const { entitlements } = await getSessionContext();

  if (!entitlements.isAuthenticated) {
    return NextResponse.redirect(new URL("/login?next=%2Fadmin", request.url));
  }

  if (!entitlements.canManageContent) {
    return NextResponse.redirect(new URL("/member", request.url));
  }

  try {
    await bootstrapMockContent();
  } catch {
    return redirectToAdmin(request, "&error=bootstrap");
  }

  return redirectToAdmin(request, "&seeded=content");
}

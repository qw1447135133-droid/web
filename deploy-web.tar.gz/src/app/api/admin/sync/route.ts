import { NextResponse } from "next/server";
import { getSessionContext } from "@/lib/session";
import { runTrackedSportsSync } from "@/lib/sync/sports-sync";

async function handleSyncRequest() {
  const { entitlements } = await getSessionContext();

  if (!entitlements.isAuthenticated) {
    return NextResponse.json(
      {
        ok: false,
        message: "Please sign in before triggering sync.",
      },
      { status: 401 },
    );
  }

  if (!entitlements.canAccessAdminConsole) {
    return NextResponse.json(
      {
        ok: false,
        message: "Admin access required.",
      },
      { status: 403 },
    );
  }

  try {
    const summary = await runTrackedSportsSync();

    return NextResponse.json({
      ok: true,
      ...summary,
    });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        message: error instanceof Error ? error.message : "Sync failed.",
      },
      { status: 500 },
    );
  }
}

export async function GET() {
  return handleSyncRequest();
}

export async function POST() {
  return handleSyncRequest();
}

import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";
import type { Locale } from "@/lib/i18n-config";
import type { SessionEntitlements, SessionUser } from "@/lib/types";

export function SiteShell({
  children,
  entitlements,
  locale,
  session,
}: {
  children: React.ReactNode;
  entitlements: SessionEntitlements;
  locale: Locale;
  session: SessionUser;
}) {
  return (
    <div className="page-frame flex min-h-screen flex-col">
      <SiteHeader locale={locale} session={session} entitlements={entitlements} />
      <main className="flex-1">{children}</main>
      <SiteFooter locale={locale} />
    </div>
  );
}

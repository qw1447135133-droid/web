"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { LocaleSwitcher } from "@/components/locale-switcher";
import type { Locale } from "@/lib/i18n-config";
import type { SessionEntitlements, SessionUser } from "@/lib/types";
import { getSiteCopy } from "@/lib/ui-copy";

export function SiteHeader({
  locale,
  session,
  entitlements,
}: {
  locale: Locale;
  session: SessionUser;
  entitlements: SessionEntitlements;
}) {
  const pathname = usePathname();
  const { brandCopy, roleLabels, sessionUiCopy, siteNavItems } = getSiteCopy(locale);
  const visibleNavItems = siteNavItems.filter(
    (item) => item.href !== "/admin" || entitlements.canAccessAdminConsole,
  );

  return (
    <header className="sticky top-0 z-30 border-b border-white/8 bg-[#06111be6] backdrop-blur-xl">
      <div className="mx-auto flex w-full max-w-7xl flex-col gap-4 px-4 py-4 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex items-center justify-between gap-4">
            <Link href="/" className="flex items-center gap-3">
              <div className="signal-ring flex h-11 w-11 items-center justify-center rounded-2xl border border-orange-400/25 bg-orange-400/10">
                <span className="display-title text-2xl font-semibold text-orange-300">S9</span>
              </div>
              <div>
                <p className="display-title text-xl leading-none font-semibold text-white">{brandCopy.title}</p>
                <p className="text-xs uppercase tracking-[0.28em] text-lime-300/80">{brandCopy.subtitle}</p>
              </div>
            </Link>

            <div className="lg:hidden">
              <LocaleSwitcher locale={locale} />
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="hidden lg:block">
              <LocaleSwitcher locale={locale} />
            </div>
            <div className="rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-slate-300">
              {session.role === "visitor"
                ? sessionUiCopy.visitorMode
                : `${session.displayName} | ${roleLabels[session.role]}`}
            </div>
            {session.role === "visitor" ? (
              <Link
                href="/login"
                className="rounded-full bg-orange-400 px-4 py-2 text-sm font-semibold text-slate-950 transition hover:bg-orange-300"
              >
                {sessionUiCopy.loginExperience}
              </Link>
            ) : (
              <form action="/api/auth/logout" method="post">
                <button
                  type="submit"
                  className="rounded-full border border-white/12 px-4 py-2 text-sm text-slate-200 transition hover:border-orange-300/40 hover:text-white"
                >
                  {sessionUiCopy.logout}
                </button>
              </form>
            )}
          </div>
        </div>

        <nav className="flex gap-2 overflow-x-auto pb-1">
          {visibleNavItems.map((item) => {
            const active =
              item.href === "/"
                ? pathname === item.href
                : pathname === item.href || pathname.startsWith(`${item.href}/`);

            return (
              <Link
                key={item.href}
                href={item.href}
                className={`shrink-0 rounded-full border px-4 py-2 text-sm transition ${
                  active
                    ? "border-orange-300/30 bg-orange-300/12 text-white"
                    : "border-white/8 bg-white/4 text-slate-300 hover:border-white/18 hover:bg-white/8 hover:text-white"
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
